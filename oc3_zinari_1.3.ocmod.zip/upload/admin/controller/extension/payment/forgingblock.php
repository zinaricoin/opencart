<?php

require_once(DIR_SYSTEM.'library/forgingblock/lib/Forgingblock.php');

class ControllerExtensionPaymentForgingblock extends Controller {
	
	var $forgingblockTrace;
	
	private $error = array();
	private $basicsettingsok;
	private $posData;
	
	
	public function index() {
		$this->load->language('extension/payment/forgingblock');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		
		$currentPrimaryContrats = $this->config->get('payment_forgingblock_primary_contracts');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {			
		
			$this->model_setting_setting->editSetting('payment_forgingblock', $this->request->post);
			if($currentPrimaryContrats == null){
				$this->session->data['success'] = $this->language->get('text_incomplete');
			} else {
				$this->session->data['success'] = $this->language->get('text_success');
			}
			$this->response->redirect($this->url->link('extension/payment/forgingblock', 'user_token=' . $this->session->data['user_token'], true));			
		}
		
		/*
		 * labels and fieldsets
		 */
		$data['heading_title']					= $this->language->get('heading_title');
		$data['text_enabled']						= $this->language->get('text_enabled');
		$data['text_disabled']					= $this->language->get('text_disabled');
		$data['text_live']					= $this->language->get('text_live');		
		$data['text_test']					= $this->language->get('text_test');
		$data['text_all_zones']					= $this->language->get('text_all_zones');
		
		
		$data['fieldset_forgingblock_module']			= $this->language->get('fieldset_forgingblock_module');		
		$data['fieldset_forgingblock_payment']			= $this->language->get('fieldset_forgingblock_payment');
		$data['fieldset_forgingblock_contracts']		= $this->language->get('fieldset_forgingblock_contracts');
		$data['fieldset_forgingblock_basicsettings']	= $this->language->get('fieldset_forgingblock_basicsettings');
		
		/*
		 * Module settings
		 */
		$data['entry_forgingblock_status']	= $this->language->get('entry_forgingblock_status');
		$data['entry_geo_zone']		= $this->language->get('entry_geo_zone');
		$data['entry_sort_order']		= $this->language->get('entry_sort_order');
		$data['entry_method_name']	= $this->language->get('entry_method_name');
		$data['help_method_name']		= $this->language->get('help_method_name');
		$data['help_forgingblock_status']	= $this->language->get('help_forgingblock_status');
		$data['help_geo_zone']		= $this->language->get('help_geo_zone');
		$data['help_sort_order']		= $this->language->get('help_sort_order');
		
		$data['entry_emi_months']	= $this->language->get('entry_emi_months');		
		$data['entry_first_monthp']	= $this->language->get('entry_first_monthp');				

		if (isset($this->request->post['payment_forgingblock_status'])) {
			$data['payment_forgingblock_status'] = $this->request->post['payment_forgingblock_status'];
		} else {
			$data['payment_forgingblock_status'] = $this->config->get('payment_forgingblock_status');
		}
		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
		if (isset($this->request->post['payment_forgingblock_geo_zone_id'])) {
			$data['payment_forgingblock_geo_zone_id'] = $this->request->post['payment_forgingblock_geo_zone_id'];
		} else {
			$data['payment_forgingblock_geo_zone_id'] = $this->config->get('payment_forgingblock_geo_zone_id');
		}
		if (isset($this->request->post['payment_forgingblock_sort_order'])) {
			$data['payment_forgingblock_sort_order'] = $this->request->post['payment_forgingblock_sort_order'];
		} else {
			$data['payment_forgingblock_sort_order'] = $this->config->get('payment_forgingblock_sort_order');
		}
		
		$method_name = $this->config->get('payment_forgingblock_method_name');
		if (isset($this->request->post['payment_forgingblock_method_name'])) {
			$data['payment_forgingblock_method_name'] = $this->request->post['payment_forgingblock_method_name'];
		} else {
			$data['payment_forgingblock_method_name'] = (isset($method_name)) ? $this->config->get('payment_forgingblock_method_name') : $this->language->get('heading_title');;
		}
		if (isset($this->error['method_name'])) {
			$data['error_method_name'] = $this->error['method_name'];
		} else {
			$data['error_method_name'] = '';
		}
		
		/*
		 * Forgingblock connection 
		 */
		$data['entry_environment']	= $this->language->get('entry_environment');
		$data['entry_trade_id']	= $this->language->get('entry_trade_id');
		$data['entry_token']		= $this->language->get('entry_token');				
		
		
		$data['help_environment']		= $this->language->get('help_environment');
		$data['help_trade_id']		= $this->language->get('help_trade_id');
		$data['help_token']		= $this->language->get('help_token');
		if (isset($this->error['environment'])) {
			$data['error_environment'] = $this->error['environment'];
		} else {
			$data['error_environment'] = '';
		}
		if (isset($this->error['trade_id'])) {
			$data['error_trade_id'] = $this->error['trade_id'];
		} else {
			$data['error_trade_id'] = '';
		}
		if (isset($this->error['token_id'])) {
			$data['error_token'] = $this->error['token_id'];
		} else {
			$data['error_token'] = '';
		}
		if (isset($this->request->post['payment_forgingblock_production'])) {
			$data['payment_forgingblock_production'] = $this->request->post['payment_forgingblock_production'];
		} else {
			$data['payment_forgingblock_production'] = $this->config->get('payment_forgingblock_production');
		}
		if (isset($this->request->post['payment_forgingblock_token_id'])) {
			$data['payment_forgingblock_trade_id'] = $this->request->post['payment_forgingblock_trade_id'];
		} else {
			$data['payment_forgingblock_trade_id'] = $this->config->get('payment_forgingblock_trade_id');
		}
		if (isset($this->request->post['payment_forgingblock_token'])) {
			$data['payment_forgingblock_token'] = $this->request->post['payment_forgingblock_token'];
		} else {
			$data['payment_forgingblock_token'] = $this->config->get('payment_forgingblock_token');
		}

		
		/*
		 * Contracts
		 */
		$data['payment_forgingblock_basicsettingsok']	= $this->config->get('payment_forgingblock_basicsettingsok');
		$data['payment_forgingblock_posData']			= $this->config->get('payment_forgingblock_posData');
		$data['entry_select_pos']			= $this->language->get('entry_select_pos');
		if($currentPrimaryContrats == null){
			$data['error_primary_contracts'] = $this->language->get('required_primary_contracts');
		} else {
			$data['error_primary_contracts'] = '';
		}
		
		/*
		 * Payment settings
		 */
		$data['entry_payment_action']	= $this->language->get('entry_payment_action');
		$data['help_payment_action']	= $this->language->get('help_payment_action');
		if (isset($this->request->post['payment_action'])) {
			$data['payment_forgingblock_payment_action'] = $this->request->post['payment_forgingblock_payment_action'];
		} else {
			$data['payment_forgingblock_payment_action'] = $this->config->get('payment_forgingblock_payment_action');
		}
		
		/*
		 * Order statuses
		 */
		$data['entry_new_status']		= $this->language->get('entry_new_status');
		$data['entry_paid_status']	= $this->language->get('entry_paid_status');
		$data['entry_confirmed_status']	= $this->language->get('entry_confirmed_status');
		$data['entry_complete_status']     = $this->language->get('entry_complete_status');
		$data['entry_expired_status']   = $this->language->get('entry_expired_status');
		$data['entry_invalid_status']   = $this->language->get('entry_invalid_status');	
		
		$data['help_new_status']			= $this->language->get('help_new_status');
		$data['help_paid_status']		= $this->language->get('help_paid_status');
		$data['help_confirmed_status']		= $this->language->get('help_confirmed_status');
		$data['help_complete_status']		= $this->language->get('help_complete_status');
		$data['help_expired_status']	= $this->language->get('help_expired_status');
		$data['help_invalid_status']	= $this->language->get('help_invalid_status');		
		$newst = $this->config->get('payment_forgingblock_new_status_id');
		
		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		if (isset($this->request->post['payment_forgingblock_new_status_id'])) {
			$data['payment_forgingblock_new_status_id'] = $this->request->post['payment_forgingblock_new_status_id'];
		} else {
			$data['payment_forgingblock_new_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_new_status_id') : '1';
		}
		if (isset($this->request->post['payment_forgingblock_paid_status_id'])) {
			$data['payment_forgingblock_paid_status_id'] = $this->request->post['payment_forgingblock_paid_status_id'];
		} else {
			$data['payment_forgingblock_paid_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_paid_status_id') : '2';
		}
		if (isset($this->request->post['payment_forgingblock_confirmed_status_id'])) {
			$data['payment_forgingblock_confirmed_status_id'] = $this->request->post['payment_forgingblock_confirmed_status_id'];
		} else {
			$data['payment_forgingblock_confirmed_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_confirmed_status_id') : '15';
		}
		if (isset($this->request->post['payment_forgingblock_complete_status_id'])) {
			$data['payment_forgingblock_complete_status_id'] = $this->request->post['payment_forgingblock_complete_status_id'];
		} else {
			$data['payment_forgingblock_complete_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_complete_status_id') : '5';
		}
		if (isset($this->request->post['expired_status_id'])) {
			$data['payment_forgingblock_expired_status_id'] = $this->request->post['payment_forgingblock_expired_status_id'];
		} else {
			$data['payment_forgingblock_expired_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_expired_status_id') : '14';
		}
		
		if (isset($this->request->post['invalid_status_id'])) {
			$data['payment_forgingblock_invalid_status_id'] = $this->request->post['payment_forgingblock_invalid_status_id'];
		} else {
			$data['payment_forgingblock_invalid_status_id'] = (isset($newst)) ? $this->config->get('payment_forgingblock_invalid_status_id') : '8';
		}
		
		/*
		 * web page customization
		 */
		$data['entry_template_url']		= $this->language->get('entry_template_url');
		$data['entry_custom_page_code']	= $this->language->get('entry_custom_page_code');
		$data['help_template_url']		= $this->language->get('help_template_url');
		$data['help_custom_page_code']	= $this->language->get('help_custom_page_code');
		if (isset($this->request->post['template_url'])) {
			$data['template_url'] = $this->request->post['template_url'];
		} else {
			$data['template_url'] = $this->config->get('template_url');
		}
		if (isset($this->request->post['custom_page_code'])) {
			$data['custom_page_code'] = $this->request->post['custom_page_code'];
		} else {
			$data['custom_page_code'] = $this->config->get('custom_page_code');
		}
		
		
				
		/*
		 * Buttons
		 */
		$data['button_save']		= $this->language->get('button_save');
		$data['button_cancel']	= $this->language->get('button_cancel');
		$data['button_search']	= $this->language->get('button_search');		

			

		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		/*
		 * Navigation
		 */
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_payment'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);
		
		
		$data['breadcrumbs'][] = array(
		       		'text'      => $this->language->get('heading_title'),
					'href'      => $this->url->link('extension/payment/forgingblock', 'user_token=' . $this->session->data['user_token'], true)
		);
		
		
		$data['action'] = $this->url->link('extension/payment/forgingblock', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('extension/payment', 'user_token=' . $this->session->data['user_token'], true);
		

		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');		
			
		$this->response->setOutput($this->load->view('extension/payment/forgingblock', $data));	
	}
	
	
	
	

	
	
	private function writeTrace($trace){
		if(!isset($this->forgingblockTrace)){
			$this->forgingblockTrace = new Log('payment_forgingblock_'.date('Y-m-d',time()).'.txt');
		}
		$this->forgingblockTrace->write($trace);
	}
	
	
	private function validate() {
		
		$exit = false;

		
		if (!$this->user->hasPermission('modify', 'extension/payment/forgingblock')) {
			$this->writeTrace("[ADMIN] - current user has no permission to edit configuration");
			$this->error['warning'] = $this->language->get('error_permission');
			$exit = true;
		}
		if (!$this->request->post['payment_forgingblock_method_name']) {
			$this->writeTrace("[ADMIN] - Zinari Cryptocurrency Gateway OpenCart method name is missing");
			$this->error['warning'] = $this->language->get('error_config');
			$this->error['method_name'] = $this->language->get('required_method_name');
			$exit = true;
		}
		if (!$this->request->post['payment_forgingblock_trade_id']) {
			$this->writeTrace("[ADMIN] - Zinari Cryptocurrency Gateway OpenCart merchant ID is missing");
			$this->error['warning'] = $this->language->get('error_config');
			$this->error['trade_id'] = $this->language->get('required_trade_id');
			$exit = true;
		}
		if (!$this->request->post['payment_forgingblock_token']) {
			$this->writeTrace("[ADMIN] - Zinari Cryptocurrency Gateway OpenCart access key is missing");
			$this->error['warning'] = $this->language->get('error_config');
			$this->error['token'] = $this->language->get('required_token');
			$exit = true;
		}
		
		if ($exit) {
			return false;
		}
		$exit = false; // reset exit flag
		
		/*
		 * A sample web service (getMerchantSettings) call is done to check the configuration
		 */
		 
		
		if (!$exit) {
			return true;
		} else {
			return false;
		}
	}
}
?>