<?php

$_['heading_title']		= 'Zinari Cryptocurrency Gateway OpenCart';

// Text
$_['text_payment']		= 'Payment';
$_['text_success']		= 'Your Zinari Cryptocurrency Gateway OpenCart configuration is correct';
$_['text_incomplete']	= 'Your Zinari Cryptocurrency Gateway OpenCart configuration is incomplete ';
$_['text_forgingblock']		= '<a onclick="window.open(&#39;http://www.forgingblock.io&#39;);"></a>';
$_['text_all_zones']	= 'All zones';
$_['text_live']	= 'Live';
$_['text_test']	= 'Test';


// Entry
$_['entry_geo_zone']     		= 'Geo Zone';
$_['entry_status']       		= 'Status';
$_['entry_sort_order']   		= 'Sort order';
$_['entry_method_name']   		= 'Method name';
$_['entry_environment']  		= 'Environment';
$_['entry_forgingblock_status'] = 'Module status';
$_['entry_trade_id']  			= 'Trade ID';
$_['entry_token']   			= 'Token';

$_['entry_new_status']     	= 'New status';
$_['entry_paid_status']     = 'Paid status';
$_['entry_confirmed_status']     = 'Confirmed status';
$_['entry_complete_status']     	= 'Complete status';
$_['entry_expired_status']    = 'Expired status';
$_['entry_invalid_status']     	= 'Invalid status';

$_['entry_template_url']   		= 'Custom template URL';
$_['entry_custom_page_code']   	= 'Custom payment page code';


$_['fieldset_forgingblock_module']			= 'General settings';
$_['fieldset_forgingblock_payment']			= 'Order Status';


// Help
$_['help_geo_zone']     	= '';
$_['help_forgingblock_status']   = '';
$_['help_sort_order']   	= '';
$_['help_method_name']   	= 'Name of the method displayed to the customer at payment method selection (checkout step 5)';
$_['help_environment']  	= '<i>Test</i> environment is for testing purpose (payments are fake). Once your tests are complete, switch to <i>live</i> environment (<i>'.$_['entry_trade_id'].'</i> ';
$_['help_trade_id']  	= 'Your Zinari Cryptocurrency Gateway OpenCart trade identification number';
$_['help_token']   	= 'Your Zinari Cryptocurrency Gateway OpenCart Token';

$_['help_new_status']     	= 'Order status when customer is redirected to Zinari Cryptocurrency Gateway OpenCart';
$_['help_paid_status']  = 'Order status when payment is paid by Zinari Cryptocurrency Gateway OpenCart';
$_['help_confirmed_status']  = 'Order status when payment is confirmed by the customer';
$_['help_complete_status']   = 'Order status when payment is complete by Zinari Cryptocurrency Gateway OpenCart';
$_['help_expired_status'] = 'Order status when payment is expired by the customer';
$_['help_invalid_status'] = 'Order status when payment is invalid by the customer';


$_['help_template_url']   	= 'URL of your own web payment page template';
$_['help_custom_page_code'] = 'code of the customization created in the Zinari Cryptocurrency Gateway OpenCart administration center';

// Error
$_['error_permission']				= 'You do not have permission to modify Zinari Cryptocurrency Gateway OpenCart payment module';
$_['required_method_name']			= $_['entry_method_name'].' required';
$_['required_trade_id']			= $_['entry_trade_id'].' required';
$_['required_token']			= $_['entry_token'].' required';
$_['required_primary_contracts']	= 'Select at least one primary contract';
$_['error_config']					= 'Your Zinari Cryptocurrency Gateway OpenCart configuration is wrong';


?>